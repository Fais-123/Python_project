// var x= 10
// console.log(x)

// let name = "ali"
// console.log(name)
// document.writeln(name)

// let age = 32
// console.log(age)
// document.writeln(age)

// c
// onst fixed value.
// const citizen= "Karachi"
// // citizen= "lahore"
// document.writeln(citizen)

// document.writeln(typeof age)
// document.writeln(typeof citizen)

//ARITHMETIC OPERATOR
// let x1=4
// let x2=5
// console.log(x1+x2)
// console.log(x1-x2)
// console.log(x1*x2)
// console.log(x1/x2)
// console.log(x1%x2) //mode operator
// console.log(x1**2) //power

//RELATIONAL/COMPARISON OPERATOR(always return result in boolean value)
// console.log(4>9)
// console.log(9>5)
// console.log(9>=9)
// console.log(8<=8)
// console.log(10=="10")
// console.log(9!=9)


// console.log(9==="9")

//LOGICAL OPERATOR
// console.log((4>5) || (2>9) || (14<8))
// console.log(!(7>8))


//Concatenation(combine strings)

let fname = "ali"
let lname = "khan"
// let output = fname + lname
// console.log(output)

//Template literals
let msg = `Hi, My name is ${fname} ${lname}`
document.writeln(msg)






