
// code for if-else with single condition
// let age = 16
// let has_license = true
// if(age > 18)
// {
//   console.log("eligible")  
// }
// else
// {
//     console.log("uneligible")
// }


// code for if-else with multiple condition using logical operators
// let age = 16
// let has_license = true
// if((age > 18) && (has_license==true))
// {
//   console.log("eligible")  
// }
// else
// {
//     console.log("uneligible")
// }

//code for if,else if and else
// let percentage = 68
// let grade = ""
// if(percentage>=90)
// {
//     grade = "A+"
// }
// else if(percentage >= 80){
//     grade="A"
// }
// else if(percentage >= 70){
//     grade="B"
// }
// else if(percentage >= 60){
//     grade="C"
// }
// else{
//     grade= "F"
// }

// console.log(grade)

// using ternary operator
// let age = 19
// let result = (age > 18)? "eligible" : "uneligible"
// console.log(result)

//user input(calculator program)
let num1 = parseInt(prompt("enter the number 1"))
let num2 = parseInt(prompt("enter the number 2"))
let op= prompt("enter any operator(+,-,*,/)")
let result 
if(op == "+")
{
    result = num1+num2
}
else if(op == "-")
{
    result = num1 - num2
}
else if(op == "*")
{
    result = num1*num2
}
else if(op == "/")
{
    result = num1/num2
}
else{
    result = "no result"
}

console.log(`The result is ${result}`)
