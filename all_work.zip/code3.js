//arrays(for multiple values storage, mixed data type values )
//CRUD operations(Create,Read,Update,Delete)
// let emp_names = ["ali","khan","sarim"]

// //Indexing
// // console.log(emp_names[1])

// //for of loop(specific for array)
// // for(let item of emp_names )
// // {
// //     console.log(item)
// // }

// //add element(push/unshift)
// emp_names.push("kamran") //end of array

// emp_names.unshift("arif") //add in array start

// //remove(pop/shift)

// emp_names.pop() //for last item removal

// emp_names.shift() //remove from start

// //update
// emp_names[1] = "Asim"


// for(let item of emp_names )
// {
//     console.log(item)
// }


//Objects

let person = {
    "name":"ahmed khan",
    "age": 24,
    "salary": 60000,
    "department":"IT"
}

//INDEXING
//.(accessor notation)
// console.log(person.salary)
// console.log(person['department'])

//add key value
person['bonus'] = 5000

// console.log(person.bonus)

//update key value
// person['salary'] = 70000
// console.log(person['salary'])

//delete key value
// delete person['salary']
// console.log(person['salary'])

//traverse objects using loop(for in specific for objects)
// for(let key in person)
// {
//     console.log(key, ":", person[key])
// }

// console.log(Object.entries(person))
// proto = {"name":"ali khan"}
// let obj= Object.create(proto)
// console.log(obj)

//freeze (no crud)-->no add,no delete,no update,but we can access and print 
// Object.freeze(person)

// // person['tax'] = 1000
// // delete person['name']
// // person['name']="ali"
// console.log(person['name'])

//seal(no add,no delete,can update)
Object.seal(person)
//update part
// person["name"]="ali"
// console.log(person['name'])

//add part
// person['tax'] = 1000
// console.log(person['tax'])

//delete part
// delete person['name']
// console.log(person['name'])

//assign(merge two objects)
let obj1={"a":1}
let obj2={"b":2}
let result = Object.assign({},obj1,obj2)
console.log(result)