
// let p_tag = document.getElementById('content')
// p_tag.textContent= "Hello world"
// console.log(p_tag)

// p_tag.innerHTML = "<b>world</b>"

// let p_class = document.getElementsByClassName('content')
// // console.log(p_class)
// p_class[0].classList.add('content')
// p_class[1].innerHTML = "<u>New Content</u>"
// document.writeln(p_class)

//NEXT CLASS
// span = document.getElementsByTagName('span')
// span[1].style.fontWeight= 'bold';



// span = document.querySelector('.content')
// span.style.background='purple'

// let myvar = document.querySelectorAll('.content')
// console.log(myvar[0])
// myvar[0].style.color="skyblue"

// myvar.forEach((item) => {
//     item.style.color="purple"
// })

//TO DO LIST

//variables
let input = document.getElementById('taskInput')
let btn = document.getElementById('taskBtn')
let list = document.getElementById('taskList')

//use eventlistener on add button
btn.addEventListener('click',()=>{
         let taskText = input.value

    if(taskText === "")
    {
        alert("enter a task")
        return;
    }
    //console.log(taskText)

       
    //creating an element 'li' to fill list
        let li_item = document.createElement("li")
        li_item.textContent = taskText
        li_item.style.fontSize=16

        //create delete for every li btn to delete li
        let deletebtn = document.createElement("button")
        deletebtn.textContent="delete"
        deletebtn.style.background= "red"
        deletebtn.style.color="white"

        deletebtn.addEventListener('click',()=>{
            //remove list item
            li_item.remove()
        })

        //to add delete btn inside li
        li_item.appendChild(deletebtn)

        //to add li inside list we use
        list.appendChild(li_item)

        //empties input field so user can refill
        input.value = ""

})




    

